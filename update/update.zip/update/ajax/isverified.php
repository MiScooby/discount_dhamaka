<?php
if (isset($_COOKIE['mob_ver'])) {
    echo $_COOKIE['mob_ver'];
}

