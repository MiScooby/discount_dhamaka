<?php

include('admin/ajax/config.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discount Dhamaka - Vendor Registration</title>

    <link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v6.1.1/css/all.css">

    <link rel="stylesheet" type="text/css" href="assets/lgn-reg-assets/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/lgn-reg-assets/vendor/font-awesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="assets/select2/select2.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/bus-style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/bus-responsive.css">
    <link rel="stylesheet" type="text/css" href="assets/css/bus-animation.css">
    <link rel="stylesheet" type="text/css" href="assets/sweetalert2/sweetalert2.min.css">
    <style>
        .select2-container {
            box-sizing: border-box;
            display: inherit;
            margin: 0;
            position: relative;
            vertical-align: middle;
        }

        .sidebar .bg-primary {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background-color: #20c997 !important;
            z-index: 9;
            opacity: 0.9;
        }

        .err_msg {
            color: red;
            font-size: 12px;
            font-weight: 500;
        }

        .err_bdr {
            border-color: red !important;
        }
    </style>
</head>

<body>

    <section class="registration-form">
        <div class="row">
            <!-- sidebar -->
            <?php
            if (!isset($_GET['byApp'])) {
                ob_start();
                session_start();
                $_SESSION['LoggedInMobile'] = 'yes';
            ?>
                <div id="sidbar" class="col-md-4 sidebar">
                    <div class="hero-bg hero-bg-scroll" style="background-image:url('assets/lgn-reg-assets/images/login-bg-1.jpg');"></div>
                    <div class="sidebar-inner" style="z-index: 99;">

                        <div class="container">
                            <div class="wrapper">
                                <div class="bus_logo">
                                    <a href="index.php">
                                        <img src="assets/images/logo/logo-8.png" alt="Discount Dhamaka">
                                    </a>
                                </div>
                                <!-- sidebar-content -->
                                <div class="sidebar-content">
                                    <div class="sidebar-text">
                                        <h2>
                                            List Your Business Online With Discount Dhamaka
                                        </h2>

                                    </div>

                                    <!-- contact-info -->
                                    <div class="contact-info">

                                        <div class="contact-info-inner">
                                            <div class="contact-icon">
                                                <i class="fa-solid fa-envelope"></i>
                                            </div>
                                            <div class="contact-details">
                                                <p>Contact via email</p>
                                                <h6><a href="mailto:support@discountdhamaka.com" style="color: #fff !important; text-decoration: none;">support@discountdhamaka.com</a></h6>
                                            </div>
                                        </div>

                                        <!-- sidebar button -->
                                        <a href="index.php"><button><i class="fa fa-arrow-left"></i> Back Home</button></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            <?php
            }
            ?>


            <!-- registration form -->
            <div id="reg-form" class="col-md-8 pop registration-form-inner h-100" style="position: relative;">

                <div id="loader" style="display: none;">
                    <div class="lds-dual-ring">
                        <div class="overlay">
                        </div>
                    </div>
                </div>

                <div class="registration-inner" id="registration-form">

                    <div class="container">
                        <div class="wrapper">

                            <div class="mytopdiv">
                                <div class="row g-0">
                                    <div class="col-12 col-md-12 col-lg-2 col-xl-12">
                                        <h3 class="fw-600">Vendor Registration With Discount Dhamaka</h3>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center my-3">
                                    <span class="mx-3 text-2 text-muted" style="margin-left:0 !important;">Register with Mobile</span>
                                    <hr class="flex-grow-1">
                                </div>
                            </div>


                            <!-- seller registration form -->
                            <form action="javascript:void(0);" id="vendor_Form" method="POST" enctype="multipart/form-data" class="form-inner srb-mt-form">
                                <div class="end_border animation-delay-25ms">
                                    <div class="row">
                                        <div class="tab-100 col-md-4">
                                            <label for="countryCode" class="form-label fw-500">Country Code <span class="req">*</span> </label>
                                            <select name="countryCode" disabled class="form-control bg-light border-light countrycodeslc2" id="vC_code">
                                                <option></option>
                                                <?php
                                                $getCountryQ = mysqli_query($con, "SELECT * FROM `country` WHERE `id`='99'");
                                                while ($getCountry = mysqli_fetch_array($getCountryQ)) {
                                                ?>
                                                    <option selected value="<?= $getCountry['phonecode'] ?>"><?= $getCountry['nicename'] . " " . $getCountry['phonecode'] ?></option>
                                                <?php
                                                } ?>
                                            </select>
                                        </div>
                                        <div class="tab-100 col-md-8">
                                            <div id="focus">
                                                <label> Mobile Number <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" maxlength="10" oninput="this.value = this.value.replace(/\D+/g, '')" name="phone" id="vMob_num" placeholder="Mobile Number">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="row" id="otpSec">
                                        <div class="tab-100 col-md-6">
                                            <div id="target1">
                                                <label>Verification Code <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" name="code" id="vOtpCode" disabled placeholder="Enter OTP">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="tab-100 col-md-6">
                                            <div class="mb-3 veribtn">
                                                <button type="button" id="sendOtpVendor" class="myotpbtn">Send Verification OTP</button>
                                                <div id="MobiSendOtpSec"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" id="bussinessDetails" style="display: none ;">
                                        <div class="py-3 col-md-12">
                                            <label class="labelHeadingSrb">Enter Vendor Personal Details :</label>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label> First Name <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" id="vF_name" name="first-name" placeholder=" First Name">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label> Last Name <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" id="vL_name" name="last-name" placeholder=" Last Name">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label> User Name <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" id="vUser_name" name="user name" placeholder="User Name">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label>Email Address <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" id="vEmail_id" name="email" placeholder="admin@example.com">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label>Password <span class="req">*</span></label>
                                                <div class="input-field pass1">
                                                    <input id="vNewPass" type="password" name="password">
                                                    <span></span>
                                                    <i toggle="#vNewPass" class="toggle-icon fa fa-eye-slash fa-eye field-icon toggle-password"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label>Confirm Password <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input id="vRePass" type="password" name="re-pass">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="ErrMsg" style="display: none;"></div>
                                        <div class="py-3 col-md-12">
                                            <label class="labelHeadingSrb">Enter Vendor Business Details :</label>
                                        </div>
                                        <div class="tab-100 col-md-6 ">
                                            <div>
                                                <label>Business Type <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <select class="form-control " id="vBusType">
                                                        <option></option>
                                                        <option value="Single brand">Single brand</option>
                                                        <option value="Multi brand">Multi brand</option>
                                                    </select>
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6 ">
                                            <div>
                                                <label>Select Category <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <select class="form-control " id="vBusCat">
                                                        <option></option>
                                                        <?php
                                                        $CateListQ = mysqli_query($con, "SELECT * FROM `category` WHERE `status`='Active'");

                                                        while ($getCateList = mysqli_fetch_array($CateListQ)) {
                                                        ?>
                                                            <option value="<?= $getCateList['id'] ?>"><?= $getCateList['cat_name'] ?></option>
                                                        <?php
                                                        }
                                                        ?>
                                                    </select>
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label> Merchant Business Name <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" id="vBusName" name="last-name" placeholder="Merchant Business Name">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label> GST No.</label>
                                                <div class="input-field">
                                                    <input type="text" maxlength="15" id="vGstNum" name="gstnumber" placeholder="GST No.">
                                                    <span></span>
                                                </div>
                                                <div id="ErrMsg1" style="display: none;"></div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-4">
                                            <div>
                                                <label> Contact Person Name <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" id="vCPname" name="last-name" placeholder=" Contact Person Name">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="tab-100 col-md-8">
                                            <div class="row">
                                                <div class="col-sm-5">
                                                    <div>
                                                        <label> Country Code <span class="req">*</span></label>
                                                        <div class="input-field">
                                                            <select disabled class="changeme form-control" id="vCp_cCode">
                                                                <option></option>
                                                                <?php
                                                                $getCountryQ = mysqli_query($con, "SELECT * FROM `country` WHERE `id`='99'");
                                                                while ($getCountry = mysqli_fetch_array($getCountryQ)) {
                                                                ?>
                                                                    <option selected value="<?= $getCountry['phonecode'] ?>"><?= $getCountry['nicename'] . " " . $getCountry['phonecode'] ?></option>
                                                                <?php
                                                                } ?>
                                                            </select>
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-7">
                                                    <div>
                                                        <label> Contact Person Phone Number <span class="req">*</span></label>
                                                        <div class="input-field">
                                                            <input type="text" maxlength="10" oninput="this.value = this.value.replace(/\D+/g, '')" id="vCPmobile" name="phone" placeholder="Person Number">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label>Contact Person Email <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="email" id="vCPemail" name="email" placeholder="admin@example.com">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label>Landline No.</label>
                                                <div class="input-field">
                                                    <input type="number" id="vLandlineNum" name="landlineno." placeholder="Landline No.">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div id="ErrMsg1" style="display: none;"></div>
                                        <div class="py-3 col-md-12">
                                            <label class="labelHeadingSrb">Enter Vendor Business Address :</label>
                                        </div>


                                        <div class="tab-100 col-md-12">
                                            <div id="locationField">
                                                <label>Address 1 <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" id="vAdd1" name="address" placeholder="Address 1">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-12">
                                            <div>
                                                <label> Address 2 <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" id="route" name="address" placeholder="Address 2">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-12">
                                            <div>
                                                <label> Locality <span class="req">*</span></label>

                                                <div class="input-field">
                                                    <input type="text" id="sublocality_level_1" name="locality" placeholder="locality">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label> City <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" id="locality" name="city" placeholder="City">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-100 col-md-6">
                                            <div>
                                                <label> State <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="text" id="administrative_area_level_1" name="state" placeholder="State">
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-50 col-md-6">
                                            <div>
                                                <label>Pincode <span class="req">*</span></label>
                                                <div class="input-field">
                                                    <input type="number" id="postal_code" name="zip-code" placeholder="10001">
                                                    <span></span>
                                                    <input type="hidden" id="latInput" placeholder="latatude" />
                                                    <input type="hidden" id="lngInput" placeholder="longitude" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row register-field">
                                            <label>
                                                <div class="label-input">
                                                    <input type="checkbox" id="agree_term" name="checkbox">
                                                </div>
                                                <div class="label-text">
                                                    I/we Confirm that I/we have read and agree to the <a href="terms-condition.php?<?= $urltoken . $urltoken ?>&&type=vendor&& <?= $urltoken . $urltoken ?>" target="_blank">Terms & Conditions</a> and <a href="privacy-policy.php?<?= $urltoken . $urltoken ?>&&type=vendor&& <?= $urltoken . $urltoken ?>" target="_blank">Privacy Policy</a>.

                                                </div>
                                            </label>
                                            <div class="reg-btn">
                                                <button type="button" id="VendorRegBtn">Register</button>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </form>

                        </div>
                    </div>
                </div>
                <style>

                </style>
                <div class="registration-stats" style="display: none;">
                    <div class="stst-content">
                        <img src="assets/images/under-process.png" width="150px" height="150px" alt="">
                        <h3>Thank You For Choosing Discount Dhamaka</h3>
                        <p>Our Excutive Will Connect With You Soon</p>
                        <a href="index.php" class="btn btn-success">Back To Home</a>
                    </div>
                </div>
                <!-- top shape -->
                <div class="shapes-top">
                    <div class="big-shape"></div>
                    <div class="small-shape"></div>
                </div>

                <!-- bottom shape -->
                <div class="shapes-bottom">
                    <div class="small-shape"></div>
                    <div class="big-shape"></div>
                </div>
            </div>
        </div>
    </section>


    <script src="assets/js/vendor/jquery-3.5.1.min.js"></script>
    <script src="assets/select2/select2.min.js"></script>
    <script src="assets/sweetalert2/sweetalert2.min.js"></script>
    <script src="assets/js/srb-validation.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBEPH7olpEltXbeZaoclKRKI-MppKsTPb0&libraries=places&callback=initMap" async defer></script>

    <script>
        var placeSearch, autocomplete;
        var componentForm = {
            route: 'short_name',
            sublocality_level_1: 'long_name',
            locality: 'long_name',
            administrative_area_level_1: 'long_name',
            postal_code: 'short_name'
        };
        var input = document.getElementById('vAdd1');

        function initMap() {
            var geocoder;
            var autocomplete;
            geocoder = new google.maps.Geocoder();
            var card = document.getElementById('locationField');
            autocomplete = new google.maps.places.Autocomplete(input);
            google.maps.event.addListener(autocomplete, 'place_changed', function() {
                fillInAddress();
            });

            function fillInAddress(new_address) {
                if (typeof new_address == 'undefined') {
                    var place = autocomplete.getPlace(input);
                    var latValue = place.geometry.location.lat();
                    var lngValue = place.geometry.location.lng();
                    // console.log(lngValue);
                    var latInput = document.getElementById('latInput');
                    var lngInput = document.getElementById('lngInput');
                    latInput.value = latValue;
                    lngInput.value = lngValue;
                } else {
                    place = new_address;
                }
                //console.log(place);
                for (var component in componentForm) {
                    document.getElementById(component).value = '';
                    document.getElementById(component).disabled = false;
                }

                for (var i = 0; i < place.address_components.length; i++) {

                    var addressType = place.address_components[i].types[0];
                    console.log(addressType);
                    if (componentForm[addressType]) {
                        var val = place.address_components[i][componentForm[addressType]];
                        document.getElementById(addressType).value = val;
                    }
                }
            }

        }
    </script>
    <script>
        $(document).ready(function() {
            $("#bussinessDetails input").attr('disabled', 'disabled')
            $("#bussinessDetails select").attr('disabled', 'disabled')
            $("#vC_code").select2({
                placeholder: "Select Country Code"
            });
            $("#vCp_cCode").select2({
                placeholder: "Select Country Code"
            });
            $("#vBusType").select2({
                placeholder: "Select brand Type"
            });
            $("#vBusCat").select2({
                placeholder: "Select Business Category"
            });



            $(document).on("click", ".toggle-password", function() {
                if ($(".pass1").find("input").attr("type") == "password") {
                    $(".pass1").find("input").attr("type", "text");
                    $(this).addClass("fa-eye");
                    $(this).removeClass("fa-eye-slash");
                } else {
                    $(".pass1").find("input").attr("type", "password");
                    $(this).removeClass("fa-eye");
                    $(this).addClass("fa-eye-slash");
                }
            });

        });
    </script>

    <script>
        $(document).on("click", "#sendOtpVendor", function() {
            vC_code = $('#vC_code').val();
            vMob_num = $('#vMob_num').val();

            if (vC_code == "") {
                swicon = "warning";
                msg = "Select Country Code Please";
                srbSweetAlret(msg, swicon);
            } else if (vMob_num == "") {
                swicon = "warning";
                msg = "Enter Mobile Number Please";
                srbSweetAlret(msg, swicon);
            } else {
                $.ajax({
                    type: "POST",
                    url: "ajax/otp.php",
                    data: {
                        vC_code: vC_code,
                        vMob_num: vMob_num,
                        type: 'VendorOtpMob',
                        usertype: 'vendor'
                    },
                    beforeSend: function() {
                        $("#loader").fadeIn(300);
                    },
                    complete: function() {
                        $("#loader").fadeOut(300);
                    },
                    success: function(data) {
                        data = JSON.parse(data);
                        if (data.status) {
                            swicon = "success";
                            msg = data.message;
                            srbSweetAlret(msg, swicon);
                            $('#vMob_num').attr('disabled', 'disabled');
                            $('#vOtpCode').removeAttr('disabled', 'disabled');
                            $('#vOtpCode').focus();
                            $("#sendOtpVendor").text('Verify Otp');
                            $("#sendOtpVendor").attr('id', 'verifyVendorMobOtp');
                            $("#MobiSendOtpSec").html('<p class="resendotp"> Resend OTP in <span id="countdowntimer">30 </span> Seconds</p>');

                            var timeleft = 30;
                            var downloadTimer = setInterval(function() {
                                timeleft--;
                                document.getElementById("countdowntimer").textContent = timeleft;
                                if (timeleft <= 0) {
                                    clearInterval(downloadTimer);
                                    $(".resendotp").html("<a href='javascript:void(0);' id='sendOtpVendor'>Resend otp</a>");
                                }

                            }, 1000);

                        } else {
                            swicon = "warning";
                            msg = data.message;
                            srbSweetAlret(msg, swicon);
                        }
                    }
                });
            }
        });

        $(document).on("click", "#verifyVendorMobOtp", function() {
            vOtpCode = $('#vOtpCode').val();
            vC_code = $('#vC_code').val();
            vMob_num = $('#vMob_num').val();

            if (vOtpCode == "") {
                swicon = "warning";
                msg = "Select Country Code Please";
                srbSweetAlret(msg, swicon);
            } else {
                $.ajax({
                    type: "POST",
                    url: "ajax/otp.php",
                    data: {
                        vOtpCode: vOtpCode,
                        vC_code: vC_code,
                        vMob_num: vMob_num,
                        type: 'VendorOtpMobVer',
                        usertype: 'vendor'
                    },
                    beforeSend: function() {
                        $("#loader").fadeIn(300);
                    },
                    complete: function() {
                        $("#loader").fadeOut(300);
                    },
                    success: function(data) {
                        data = JSON.parse(data);
                        if (data.status) {
                            swicon = "success";
                            msg = data.message;
                            srbSweetAlret(msg, swicon);
                            $("#bussinessDetails input").removeAttr('disabled', 'disabled');
                            $("#bussinessDetails select").removeAttr('disabled', 'disabled');
                            $("#bussinessDetails").show();
                            $('#vMob_num').attr('disabled', 'disabled');
                            $('#vC_code').attr('disabled', 'disabled');
                            $("#otpSec").hide();
                            $('#vendor_Form').removeClass('srb-mt-form');
                            $('#vF_name').focus();
                        } else {
                            swicon = "warning";
                            msg = data.message;
                            srbSweetAlret(msg, swicon);
                            $('#vMob_num').val();
                            $('#vC_code').select2();
                        }
                    }
                });
            }
        });

        function mobileVerified() {

            let mobileVerified;
            $.ajax({
                url: "ajax/otp.php",
                type: "POST",
                async: false,
                data: {
                    type: 'mobileVerified'
                },
                success: function(data) {

                    if (data) {
                        mobileVerified = data;
                    } else {
                        mobileVerified = data;
                    }
                }
            });

            return mobileVerified;
        }

        $("#vNewPass").on("keyup", function(e) {
            $(this).prop('type', 'password');
            var value = $(this).val();
            if (value != '') {
                var regex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,15}$/;
                var isValid = regex.test(value);
                if (!isValid) {
                    $('#VendorRegBtn').attr('disabled', 'disabled');
                    $("#vNewPass").addClass('err_bdr');
                    $("#ErrMsg").show();
                    $("#ErrMsg").html("<div class='err_msg' id='" + this.id + "ErrMsg'>Password must between 6 to 15 characters which contain at least one numeric digit, one uppercase and one lowercase letter</div>");
                } else {
                    $("#ErrMsg").hide();
                    $('#VendorRegBtn').removeAttr('disabled', 'disabled');
                    $("#vNewPass").removeClass('err_bdr');
                }
            }
        });

        $("#vGstNum").on("keyup", function(e) {
            $(this).prop('type', 'text');
            var value = $(this).val();
            if (value != '') {
                var regex = /[0-9]{2}[A-Z]{3}[ABCFGHLJPTF]{1}[A-Z]{1}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
                var isValid = regex.test(value);
                if (!isValid) {
                    $('#VendorRegBtn').attr('disabled', 'disabled');
                    $("#vGstNum").addClass('err_bdr');
                    $("#ErrMsg1").show();
                    $("#ErrMsg1").html("<div class='err_msg' id='" + this.id + "ErrMsg1'>Please Enter Valid GSTIN Number. eg : 07IWTSG8757B1X1</div>");
                } else {
                    $("#ErrMsg1").hide();
                    $('#VendorRegBtn').removeAttr('disabled', 'disabled');
                    $("#vGstNum").removeClass('err_bdr');
                }
            } else {
                $("#ErrMsg1").hide();
                $('#VendorRegBtn').removeAttr('disabled', 'disabled');
                $("#vGstNum").removeClass('err_bdr');
            }
        });

        $(document).on("click", "#VendorRegBtn", function() {
            vC_code = $('#vC_code').val();
            vMob_num = $('#vMob_num').val();
            vMob_ver = mobileVerified();
            vF_name = $('#vF_name').val();
            vL_name = $('#vL_name').val();
            vUser_name = $('#vUser_name').val();
            vEmail_id = $('#vEmail_id').val();
            vNewPass = $('#vNewPass').val();
            vRePass = $('#vRePass').val();
            vBusType = $('#vBusType').val();
            vBusCat = $('#vBusCat').val();
            vBusName = $('#vBusName').val();
            vCPname = $('#vCPname').val();
            vCPemail = $('#vCPemail').val();
            vCp_cCode = $('#vCp_cCode').val();
            vCPmobile = $('#vCPmobile').val();
            vGstNum = $('#vGstNum').val();
            vLandlineNum = $('#vLandlineNum').val();
            vAdd1 = $('#vAdd1').val();
            vAdd2 = $('#route').val();
            locality = $('#sublocality_level_1').val();
            vCity = $('#locality').val();
            vState = $('#administrative_area_level_1').val();
            vZipCode = $('#postal_code').val();
            vLatCode = $('#latInput').val();
            vLngCode = $('#lngInput').val();
            $agree_term = $("#agree_term").prop('checked');

            if (vC_code == "") {
                swicon = "warning";
                msg = "Select Country Code Please";
                srbSweetAlret(msg, swicon);
            } else if (vMob_num == "") {
                swicon = "warning";
                msg = "Enter Mobile Number Please";
                srbSweetAlret(msg, swicon);
            } else if (vMob_ver !== "1" && vMob_ver == "0") {
                swicon = "warning";
                msg = "Please Verify Your mobile";
                srbSweetAlret(msg, swicon);
            } else if (vF_name == "") {
                swicon = "warning";
                msg = "Enter First Name Please";
                srbSweetAlret(msg, swicon);
            } else if (vL_name == "") {
                swicon = "warning";
                msg = "Enter Last Name Please";
                srbSweetAlret(msg, swicon);
            } else if (vUser_name == "") {
                swicon = "warning";
                msg = "Enter User Name Please";
                srbSweetAlret(msg, swicon);
            } else if (vEmail_id == "") {
                swicon = "warning";
                msg = "Enter Email Address Please";
                srbSweetAlret(msg, swicon);
            } else if (vNewPass == "") {
                swicon = "warning";
                msg = "Enter Your Password Please";
                srbSweetAlret(msg, swicon);
            } else if (vRePass == "") {
                swicon = "warning";
                msg = "Enter Confirm Password Please";
                srbSweetAlret(msg, swicon);
            } else if (vBusType == "") {
                swicon = "warning";
                msg = "Select Business Type Please";
                srbSweetAlret(msg, swicon);
            } else if (vBusCat == "") {
                swicon = "warning";
                msg = "Select Business Category Please";
                srbSweetAlret(msg, swicon);
            } else if (vBusName == "") {
                swicon = "warning";
                msg = "Enter Business Name Please";
                srbSweetAlret(msg, swicon);
            } else if (vCPname == "") {
                swicon = "warning";
                msg = "Enter Contact Person Name";
                srbSweetAlret(msg, swicon);
            } else if (vCp_cCode == "") {
                swicon = "warning";
                msg = "Select Contact Person C.Code";
                srbSweetAlret(msg, swicon);
            } else if (vCPmobile == "") {
                swicon = "warning";
                msg = "Enter Contact Person Mobile";
                srbSweetAlret(msg, swicon);
            } else if (vCPemail == "") {
                swicon = "warning";
                msg = "Enter Contact Person Email";
                srbSweetAlret(msg, swicon);
            } else if (vAdd1 == "") {
                swicon = "warning";
                msg = "Enter Address Please";
                srbSweetAlret(msg, swicon);
            } else if (vCity == "") {
                swicon = "warning";
                msg = "Enter Your City Please";
                srbSweetAlret(msg, swicon);
            } else if (vState == "") {
                swicon = "warning";
                msg = "Enter Your State Please";
                srbSweetAlret(msg, swicon);
            } else if (vZipCode == "") {
                swicon = "warning";
                msg = "Enter ZIP Code Please";
                srbSweetAlret(msg, swicon);
            } else if ($agree_term == false) {
                swicon = "warning";
                msg = "Please Agree Terms & Conditions";
                srbSweetAlret(msg, swicon);

            } else {
                $.ajax({
                    type: "POST",
                    url: "ajax/registration.php",
                    data: {
                        vC_code: vC_code,
                        vMob_num: vMob_num,
                        vMob_ver: vMob_ver,
                        vF_name: vF_name,
                        vL_name: vL_name,
                        vUser_name: vUser_name,
                        vEmail_id: vEmail_id,
                        vNewPass: vNewPass,
                        vRePass: vRePass,
                        vBusType: vBusType,
                        vBusCat: vBusCat,
                        vBusName: vBusName,
                        vCPname: vCPname,
                        vCPemail: vCPemail,
                        vCp_cCode: vCp_cCode,
                        vCPmobile: vCPmobile,
                        vGstNum: vGstNum,
                        vLandlineNum: vLandlineNum,
                        vAdd1: vAdd1,
                        vAdd2: vAdd2,
                        locality: locality,
                        vCity: vCity,
                        vState: vState,
                        vZipCode: vZipCode,
                        vLatCode: vLatCode,
                        vLngCode: vLngCode,
                        type: 'vendor_reg'
                    },
                    beforeSend: function() {
                        $("#loader").fadeIn(300);
                    },
                    complete: function() {
                        $("#loader").fadeOut(300);
                    },
                    success: function(data) {
                        data = JSON.parse(data);
                        if (data.status) {
                            swicon = "success";
                            msg = data.message;
                            srbSweetAlret(msg, swicon);

                            location.href = data.url;
                        } else {
                            swicon = "warning";
                            msg = data.message;
                            srbSweetAlret(msg, swicon);
                        }
                    }
                });
            }
        });
    </script>
</body>

</html>