<?php include('includes/header.php'); ?>
<link rel="stylesheet" href="assets/css/contact-us.css">
<!-- header end here -->

<section class="ec-page-content section-space-p contactpg">
    <div class="container">
        <div class="row">
            <div class="ec-common-wrapper">
                <div class="row">

                    <div class="col-md-7">
                        <div class="ec-contact-leftside">
                            <div class="ec-contact-container">
                                <div class="ec-contact-form">
                                    <form action="javascript:void(0);" id="contatForm" method="post">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <span class="ec-contact-wrap">
                                                    <label>Name*</label>
                                                    <input type="text" name="CntcName" placeholder="Enter your name" required />
                                                </span>
                                            </div>
                                            <div class="col-md-6">
                                                <span class="ec-contact-wrap">
                                                    <label>Email*</label>
                                                    <input type="email" name="CntcEmail" placeholder="Enter email address" required />
                                                </span>
                                            </div>
                                            <div class="col-md-6">
                                                <span class="ec-contact-wrap">
                                                    <label>Phone Number*</label>
                                                    <input type="text" name="CntcPhn"   maxlength="10" oninput="this.value = this.value.replace(/\D+/g, '')" placeholder="Enter mobile number" required />
                                                </span>
                                            </div>
                                            <div class="col-md-12">
                                                <span class="ec-contact-wrap">
                                                    <label>Query*</label>
                                                    <textarea name="CntcQuery" required placeholder="Please leave your comments here.."></textarea>
                                                </span>
                                            </div>
                                            <div class="col-md-12">
                                                <span class="ec-contact-wrap ec-contact-btn">
                                                    <button class="btn btn-primary" type="submit">Send Query</button>
                                                </span>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="ec-contact-rightside">
                            <div class="ec_contact_info">
                                <h1 class="ec_contact_info_head">Contact us</h1>
                                <ul class="align-items-center">

                                    <li class="ec-contact-item">
                                        <span><i class="ecicon eci-envelope" aria-hidden="true"></i><span>Email :</span></span>
                                        <span class="myfntcnt"><a href="mailto:#">info@dicountdhamaka.com</a></span>
                                    </li>
                                </ul>
                            </div>
                            <div class="ec_contact_map">
                                <div class="ec_map_canvas">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3499.864049655993!2d77.14908586454469!3d28.69371311418341!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d031c9a539885%3A0x6eeaa336893a5c65!2sD%20Mall!5e0!3m2!1sen!2sin!4v1670046681694!5m2!1sen!2sin" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- footer start here -->
<?php include('includes/footer.php'); ?>
<script>
    function srbSweetAlret(msg, swicon) {
        msg = msg;
        swicon = swicon;
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        Toast.fire({
            icon: swicon,
            title: msg
        })
    }
</script>
<script>
    $(document).on('submit', '#contatForm', function() {
        $.ajax({

            type: "POST",
            url: "ajax/contact.php",
            processData: false,
            contentType: false,
            data: new FormData(this),
         
            success: function(data) {
                data = JSON.parse(data);
                if (data.status) {
                    swicon = "success";
                    msg = data.message;
                    srbSweetAlret(msg, swicon);
                    window.setTimeout(function() {
                                location.reload();
                            }, 1000);
                } else {
                    swicon = "warning";
                    msg = data.message;
                    srbSweetAlret(msg, swicon);
                }
            }

        });
    });
</script>